import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import copy
import math
import pymap3d as pm

from multiprocessing import Process, Value
from datetime import datetime
from canlib import canlib, Frame, kvadblib
from canlib.canlib import ChannelData
import time as timee


def transform_coor(yaw, x, y):

    if yaw >= -math.pi and yaw <= math.pi / 2:

        theta = math.pi / 2 - yaw
    else:
        theta = math.pi * 2.5 - yaw

    x_x = math.cos(theta) * x - math.sin(theta) * y

    y_y = math.sin(theta) * x + math.cos(theta) * y


    return x_x, y_y



def main():
    # pi = 3.14
    #
    # theta = math.pi / 4
    # tilt = math.tan(theta) # math 함수에서 들어가는 값은 pi꼴로 들어간다고 생각하는게 편함! 각도로 넣을것 ex pi / 4
    coor_ENU = [[5, 10], [-5, 10], [-5, -10], [5, -10]]
    coor_ENU = np.array(coor_ENU)

    x_axes = []
    for i in range(30):
        if i == 0:
            pass
        x_axes.append([i,0])
        #x_axes.append([-i, 0])

    y_axes = []
    for i in range(30):
        if i == 0:
            pass
        y_axes.append([0,i])
        #y_axes.append([0,-i])

    # transpormation
    a = 3
    b = 4
    yaw = math.pi / 4

    y_axes = np.array(y_axes)
    x_axes = np.array(x_axes)

    #--------------------평행이동 먼저 하면 오류 발생.... 대체 왜????------------
    x_trans = []
    for i in range(30):
        if i == 0:
            pass
        print(x_axes[0,1])
        x = x_axes[i,0] + a  # x값 평행이동
        y = x_axes[i,1] + b  # y값 평행이동

        x, y = transform_coor(yaw, x, y)

        x_trans.append([x,y])

    y_trans = []
    for i in range(30):
        if i == 0:
            pass
        x = y_axes[i, 0] + a  # x값 평행이동
        y = y_axes[i, 1] + b  # y값 평행이동

        x, y = transform_coor(yaw, x, y)

        y_trans.append([x, y])

    # --------------------평행이동 먼저 하면 오류 발생.... 대체 왜????------------


    # #-----------각도 시뮬레이션--------------
    theta_x = (math.pi / 4)
    tilt_x = math.tan(theta_x)

    theta_y = theta_x + math.pi / 2
    tilt_y = math.tan(theta_y)

    yaw = (math.pi / 4)  # yaw 값은 상황에 따라 계속 바꿔줄것
    # -----------각도 시뮬레이션--------------

    car_x_axes = []
    a = 3
    b = 4

    for i in range(50):
        if i == 0:
            pass
        car_x_axes.append([i + a, tilt_x * i + b])
        car_x_axes.append([-i+ a, tilt_x * (-i) + b])



    car_y_axes = []
    for i in range(50):
        if i == 0:
            pass
        car_y_axes.append([i+ a, tilt_y * i + b])
        car_y_axes.append([-i+ a, tilt_y * (-i) + b])
    #
    # # --------------------차량 좌표 변환, 회전 먼저----------------------------
    #
    # x_trans = []
    # for i in range(30):
    #     if i == 0:
    #         pass
    #
    #     x = x_axes[i, 0]
    #     y = x_axes[i, 1]
    #
    #     x, y = transform_coor(yaw, x, y)
    #     x = x + a
    #     y = y + b
    #     x_trans.append([x, y])
    #
    # y_trans = []
    # for i in range(30):
    #     if i == 0:
    #         pass
    #     x = y_axes[i, 0]
    #     y = y_axes[i, 1]
    #
    #     x, y = transform_coor(yaw, x, y)
    #     x = x + a
    #     y = y + b
    #     y_trans.append([x, y])
    # # --------------------차량 좌표 변환, 회전 먼저---------------------------
    coor_ENU2car = []
    for i in range(4):
        x = coor_ENU[i,0]
        y = coor_ENU[i, 1]
        x = x + a
        y = y + b
        x, y = transform_coor(yaw, x, y)

        coor_ENU2car.append([x,y])

    coor_ENU2car = np.array(coor_ENU2car)

    x_trans = np.array(x_trans)
    y_trans = np.array(y_trans)

    car_x_axes = np.array(car_x_axes)
    car_y_axes = np.array(car_y_axes)

    plt.plot(coor_ENU2car[0, 0], coor_ENU2car[0, 1], "ob", markersize=3)
    plt.plot(coor_ENU2car[1, 0], coor_ENU2car[1, 1], "ok", markersize=3)
    plt.plot(coor_ENU2car[2, 0], coor_ENU2car[2, 1], "ok", markersize=3)
    plt.plot(coor_ENU2car[3, 0], coor_ENU2car[3, 1], "ok", markersize=3)

    plt.plot(coor_ENU[0, 0], coor_ENU[0, 1], "or", markersize=3)

    plt.plot(coor_ENU[1, 0], coor_ENU[1, 1], "ok", markersize=3)
    plt.plot(coor_ENU[2, 0], coor_ENU[2, 1], "ok", markersize=3)
    plt.plot(coor_ENU[3, 0], coor_ENU[3, 1], "ok", markersize=3)
    plt.plot(x_axes[:,0],x_axes[:,1],  '--k', linewidth=1)
    plt.plot(y_axes[:,0],y_axes[:,1],  '--k', linewidth=1)

    plt.plot(car_y_axes[:, 0], car_y_axes[:, 1], '--b', linewidth=1)
    plt.plot(car_x_axes[:, 0], car_x_axes[:, 1], '--g', linewidth=1)

    plt.plot(y_trans[:, 0], y_trans[:, 1], '--k', linewidth=3)
    plt.plot(x_trans[:, 0], x_trans[:, 1], 'ok', linewidth=3) # 차가 바라보고 있는 방향

    plt.grid(True)

    plt.plot()
    plt.ylim(-30, 30)  # - 15, +15
    plt.xlim(-30, 30)


    plt.show()

    a = math.atan2(-1, 1)
    a = a * 180 / math.pi
    print(a)
if __name__ == "__main__":
    main()
