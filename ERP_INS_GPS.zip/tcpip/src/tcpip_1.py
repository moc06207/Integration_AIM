#!/usr/bin/env python
#-*- coding:utf-8 -*-	# 한글 주석을 달기 위해 사용한다.
import rospy
from std_msgs.msg import String
from sensor_msgs.msg import Imu, MagneticField, NavSatFix, PointCloud2
import socket
import time
from multiprocessing import Value, Process, Manager
import struct 
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import math
import copy
import numpy as np
from scipy import linalg
import pymap3d as pm
from JU_matrix import Kalman_Filter, m_n_inverse, n_n_inverse,DCM2eul_bn,eul2DCM_bn,product_matrix_dx,product_matrix,skew,plus_matrix,minus_matrix,cross_product,n_1_inverse


show_animation = True

def chatterCallback(data):



    current_accel_x.value, current_accel_y.value, current_accel_z.value = round(data.linear_acceleration.x,2), round(data.linear_acceleration.y,2), round(data.linear_acceleration.z,2)

    current_vel_x.value, current_vel_y.value,current_vel_z.value = round(data.angular_velocity.x,5), round(data.angular_velocity.y,5), round(data.angular_velocity.z,5)

    current_quat_x.value, current_quat_y.value, current_quat_z.value, current_quat_w.value = round(data.orientation.x,2), round(data.orientation.y,2), round(data.orientation.z,2), round(data.orientation.w,2)

    quat_list = [current_quat_x.value, current_quat_y.value,current_quat_z.value, current_quat_w.value]

    roll, pitch, yaw = euler_from_quaternion(quat_list)

    yaw = math.degrees(yaw)

    #current_yaw.value = round(yaw, 4)
    current_roll.value = round(roll, 4)
    current_pitch.value = round(pitch, 4)

    IMU_CTC.value = 1
    IMU_CNT.value += 1
    if IMU_CNT.value > 255:
        IMU_CNT.value = 0
    
    # 이유는 모르겠으나 def GPSINS에서 yaw값을 산출하면 속도는 엄청나게 빠르나 중간에 계속 렉 걸리면서 컴퓨터가 멈춰버림
    # 안정성을 위해서 callback에서 처리하는게 나을까?



def LidarCallback(data):

    data = data.data



    #final_obj = [[0 for k in range(7)] for i in range(4)]
    
    final_obj = []

    a = [0 for k in range(7)]

    if len(data) == 4:
        final_obj = [a for i in range(7)]
        pass
    else:
        for i in range((len(data) - 4) / 28):

            obj = data[28 * i + 4 : 28 * i + 32]
            obj_list = []

            for i in range(7):
               
                num = round(float(obj[4 * i : 4 * i + 4]) * 0.01,2)

                if float(obj[4 * i + 3])%2==1:
                    num = num*(-1)                    
                else:
                    pass
                #print(num) #include minus, display number
                obj_list.append(num)

                

            final_obj.append(obj_list)
        
            
  
        num = 7 - len(final_obj)

        for i in range(num):
            final_obj.append(a)
    
    obj1_dist.value   = final_obj[0][0]
    obj1_x_cent.value = final_obj[0][1]
    obj1_y_cent.value = final_obj[0][2]
    obj1_x_min.value  = final_obj[0][3]
    obj1_x_max.value  = final_obj[0][4]
    obj1_y_min.value  = final_obj[0][5]
    obj1_y_max.value  = final_obj[0][6]

    
    obj2_dist.value   = final_obj[1][0]
    obj2_x_cent.value = final_obj[1][1]
    obj2_y_cent.value = final_obj[1][2]
    obj2_x_min.value  = final_obj[1][3]
    obj2_x_max.value  = final_obj[1][4]
    obj2_y_min.value  = final_obj[1][5]
    obj2_y_max.value  = final_obj[1][6]

    obj3_dist.value   = final_obj[2][0]
    obj3_x_cent.value = final_obj[2][1]
    obj3_y_cent.value = final_obj[2][2]
    obj3_x_min.value  = final_obj[2][3]
    obj3_x_max.value  = final_obj[2][4]
    obj3_y_min.value  = final_obj[2][5]
    obj3_y_max.value  = final_obj[2][6]

    obj4_dist.value   = final_obj[3][0]
    obj4_x_cent.value = final_obj[3][1]
    obj4_y_cent.value = final_obj[3][2]
    obj4_x_min.value  = final_obj[3][3]
    obj4_x_max.value  = final_obj[3][4]
    obj4_y_min.value  = final_obj[3][5]
    obj4_y_max.value  = final_obj[3][6]

    LIDAR_CTC.value = 1
    LIDAR_CNT.value += 1

    if LIDAR_CNT.value > 255:
        LIDAR_CNT.value = 0

    if obj1_dist.value > 0:
        LIDAR_obj_1.value = 1
    else:
        LIDAR_obj_1.value = 0

    if obj2_dist.value > 0:
        LIDAR_obj_2.value = 1
    else:
        LIDAR_obj_2.value = 0

    if obj3_dist.value > 0:
        LIDAR_obj_3.value = 1
    else:
        LIDAR_obj_3.value = 0

    if obj4_dist.value > 0:
        LIDAR_obj_4.value = 1
    else:
        LIDAR_obj_4.value = 0


    #obj = [dist,x_cent, y_cent, x_min,x_max, y_min, y_max]
    
   
    
def GPSCallback(data):

    current_lat.value, current_lon.value, current_alt.value = data.latitude, data.longitude, data.altitude
    if current_lat.value >= 0:
        GPS_CTC.value = 1
        GPS_CNT.value += 1
        if GPS_CNT.value > 255:
            GPS_CNT.value = 0
   
  
    
def GPSINS(current_lat, current_lon, current_alt, current_accel_x,
    current_accel_y, current_accel_z,current_vel_x, current_vel_y,current_vel_z,
    current_quat_x, current_quat_y, current_quat_z, 
    current_quat_w,current_yaw,
    obj1_dist,obj2_dist,obj3_dist,obj4_dist,
    obj1_x_cent,obj2_x_cent,obj3_x_cent,obj4_x_cent,
    obj1_y_cent,obj2_y_cent,obj3_y_cent ,obj4_y_cent,
    obj1_x_min,obj2_x_min,obj3_x_min,obj4_x_min,
    obj1_x_max,obj2_x_max,obj3_x_max,obj4_x_max,
    obj1_y_min,obj2_y_min,obj3_y_min,obj4_y_min,
    obj1_y_max,obj2_y_max,obj3_y_max,obj4_y_max,
    IMU_CTC, IMU_CNT, GPS_CTC,GPS_CNT,LIDAR_CTC,LIDAR_CNT,
    LIDAR_obj_1,LIDAR_obj_2,LIDAR_obj_3,LIDAR_obj_4,
    current_roll,current_pitch):


    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber("vectornav/IMU", Imu, chatterCallback)

    rospy.Subscriber("Lidar_msg", String, LidarCallback)
    
    rospy.Subscriber("raw_data/fix", NavSatFix, GPSCallback)
    
    rospy.spin()

   

def tcpip(current_lat, current_lon, current_alt, current_accel_x,
    current_accel_y, current_accel_z,current_vel_x, current_vel_y,current_vel_z,
    current_quat_x, current_quat_y, current_quat_z,
    current_quat_w,current_yaw,
    obj1_dist,obj2_dist,obj3_dist,obj4_dist,
    obj1_x_cent,obj2_x_cent,obj3_x_cent,obj4_x_cent,
    obj1_y_cent,obj2_y_cent,obj3_y_cent ,obj4_y_cent,
    obj1_x_min,obj2_x_min,obj3_x_min,obj4_x_min,
    obj1_x_max,obj2_x_max,obj3_x_max,obj4_x_max,
    obj1_y_min,obj2_y_min,obj3_y_min,obj4_y_min,
    obj1_y_max,obj2_y_max,obj3_y_max,obj4_y_max,
    IMU_CTC, IMU_CNT, GPS_CTC,GPS_CNT,LIDAR_CTC,LIDAR_CNT,
    LIDAR_obj_1,LIDAR_obj_2,LIDAR_obj_3,LIDAR_obj_4,kalman_yaw):
    
    #host = "192.168.1.99" # 서버 컴퓨터의 ip(여기선 내 컴퓨터를 서버 컴퓨터로 사용) 
                       # 본인의 ip주소 넣어도 됨(확인방법: cmd -> ipconfig)
    port = 4567  # 서버 포트번호(다른 프로그램이 사용하지 않는 포트번호로 지정해야 함)
    host = "192.168.10.22"
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((host, port))

    # 클라이언트 접속 준비 완료
    server_socket.listen(1)

    print('echo server start')

    #  클라이언트 접속 기다리며 대기 
    client_soc, addr = server_socket.accept()

    print('connected client addr:', addr)
    print("통신 진행 중")
    # 클라이언트가 보낸 패킷 계속 받아 에코메세지 돌려줌
    while True:
     
       
        msg = struct.pack('>38d', 
        current_lat.value, current_lon.value, current_alt.value, kalman_yaw.value,
        obj1_dist.value, obj1_x_cent.value, obj1_y_cent.value, obj1_x_min.value,
        obj1_x_max.value, obj1_y_min.value,obj1_y_max.value,
        obj2_dist.value, obj2_x_cent.value, obj2_y_cent.value, obj2_x_min.value,
        obj2_x_max.value, obj2_y_min.value,obj2_y_max.value,
        obj3_dist.value, obj3_x_cent.value, obj3_y_cent.value, obj3_x_min.value,
        obj3_x_max.value, obj3_y_min.value,obj3_y_max.value,
        obj4_dist.value, obj4_x_cent.value, obj4_y_cent.value, obj4_x_min.value,
        obj4_x_max.value, obj4_y_min.value,obj4_y_max.value,
        IMU_CTC.value, IMU_CNT.value, GPS_CTC.value,GPS_CNT.value,
        LIDAR_CTC.value,LIDAR_CNT.value
        )
        
        client_soc.sendall(msg)
        data = client_soc.recv(65535)

    print("통신 끝")
    server_socket.close() # 사용했던 서버 소켓을 닫아줌"""



def vn100_Kalman_filter(current_lat, current_lon, current_alt, current_accel_x,
    current_accel_y, current_accel_z,current_vel_x, current_vel_y,current_vel_z,current_yaw,
                  current_roll,current_pitch,GPS_CNT,kalman_yaw,GPS_CTC):

    GPS_comp_plot = np.empty((0, 2), float)

    Kalman_comp_plot= np.empty((0, 2), float)

    degree = math.pi / 180
    radian = 180 / math.pi
    while True:

        if GPS_CTC.value != 0:
            print("GPS/INS Integration Start!")

            Q = [[0 for j in range(15)] for i in range(15)]

            Q[0][0] = 1000.0  # LLH
            Q[1][1] = 1000.0
            Q[2][2] = 1000.0
            Q[3][3] = 1000 # v_ned
            Q[4][4] = 1000
            Q[5][5] = 1000.0
            Q[6][6] = 0.001  # rpy
            Q[7][7] = 0.001
            Q[8][8] = 0.001
            Q[9][9] = 0.1  # accel
            Q[10][10] = 0.1
            Q[11][11] = 0.1
            Q[12][12] = 0.1  # gyro
            Q[13][13] = 0.1
            Q[14][14] = 0.1

            Q = np.array(Q) * 10000

            P = [[0 for j in range(15)] for i in range(15)]

            for i in range(15):
                P[i][i] = 0.01

            P = np.array(P)

            R = [[0 for j in range(6)] for i in range(6)]

            for i in range(6):
                R[i][i] = 1.0

            R = np.array(R)

            H = [[0 for j in range(15)] for i in range(6)]

            for i in range(6):
                H[i][i] = 1

            H = np.array(H)

            start_time = time.time()  # dt산출을 위해서! # 기존 로그기반 필터는 i ~ i + 1 로 시간을 산출했으나,
            # 실시간은 i-1 ~ i로 산출해야함!


            start_lat,start_lon,start_alt = current_lat.value, current_lon.value, current_alt.value

            time.sleep(1)
            print('Attitude Initialization')

            N, E, D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value, start_lat,
                                      start_lon, start_alt)

            GPS_v_n,GPS_v_e,GPS_v_d = (N - 0) / 1,(E - 0) / 1,(D - 0) / 1 # 1초 멈췄으니까 1로 처

            init_N, init_E, init_D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value,
                                                     start_lat, start_lon, start_alt)
            # if init_N == 0 and init_E == 0:
            #     pass
            #
            # else:
            #

            init_yaw = math.atan2(init_E, init_N) * radian #atan2 덕분에 사분면 상관없이 yaw 나옴
            # init_yaw = math.atan2(-1, 1) * radian
            #
            # print(init_yaw) #이거 해보면 됨 그럼 이해


            X0 = np.array([current_lat.value,current_lon.value, current_alt.value,
                           GPS_v_n, GPS_v_e, GPS_v_d,
                           current_roll.value, current_pitch.value,
                           init_yaw])  # set initial state  RTK 와 IMU 를 이용했음

            dX0 = [
                [0],
                [0],
                [0],
                [0],
                [0],
                [0],
                [1],
                [1],
                [2],
                [0.14],
                [0.14],
                [0.14],
                [0.0035],
                [0.0035],
                [0.0035],
            ]
            dX0 = np.array(dX0)

            ecc = 0.0818192  # earth's eccentricity
            R0 = 6378137.0  # earth's mean radius (m)
            Ome = 7.2921151467e-5  # earth's rotational rate (rad/s)
            g = 9.81  # gravity
            ecc_2 = ecc ** 2

            X = X0
            dX = copy.deepcopy(dX0)


            prev_N, prev_E, prev_D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value,
                                                     start_lat, start_lon, start_alt)

            # TODo interval[i]는 i부터 i+1까지의 시간이다.

            G_CNT = GPS_CNT.value
            while True:


                dt = time.time() - start_time # i-1 ~ i 까지의 시간차
                start_time = time.time() # i-1 시간 다시 갱신

                # state update with X
                lat, lon, h = X[0], X[1], X[2]
                v_n, v_e, v_d = X[3], X[4], X[5]
                roll, pitch, yaw = X[6], X[7], X[8]
                kalman_yaw.value = yaw


                # earth model
                # matlab sind = sin(lat * pi / 180)
                Rm = R0 * (1 - ecc_2) / (1 - ecc_2 * (math.sin(lat * degree)) ** 2) ** 1.5
                Rt = R0 / (1 - ecc_2 * (math.sin(lat * degree)) ** 2) ** 0.5
                Rmm = (3 * R0 * (1 - ecc_2) * ecc_2 * math.sin(lat * degree)) * math.cos(lat * degree) / (
                            (1 - ecc_2 * (math.sin(lat * degree)) ** 2) ** 2.5)

                Rtt = R0 * ecc_2 * math.sin(lat * degree) * math.cos(lat * degree) / ((1 - ecc_2
                                                                                       * (math.sin(lat * degree)) ** 2) ** 1.5)

                # gyro measurement
                w_ibb = np.array([current_vel_x.value, current_vel_y.value, current_vel_z.value]) # gyro 값
                w_enn = np.array([v_e / (Rt + h), -v_n / (Rm + h), -v_e * math.tan(lat * degree) / (Rt + h)])
                rho_n, rho_e, rho_d = w_enn[0], w_enn[1], w_enn[2]
                w_ien = np.array([Ome * math.cos(lat * degree), 0, - Ome * math.sin(lat * degree)])
                w_inn = np.array([w_ien[0] + w_enn[0], w_ien[1] + w_enn[1], w_ien[2] + w_enn[2]])
                Cbn = np.array(eul2DCM_bn(roll, pitch,yaw))  # body to ned DCM
               
                # accel measurement
                f_ned = Cbn @ np.array([[current_accel_x.value],[current_accel_y.value], [current_accel_z.value]])  # body to ned accel

                f_n, f_e, f_d = f_ned[0][0], f_ned[1][0], f_ned[2][0]

                # mechanization
                Cbn = Cbn + (Cbn @ np.array(skew(w_ibb[0] - dX[12][0], w_ibb[1] - dX[13][0], w_ibb[2] - dX[14][0])) -
                             np.array(skew(w_inn[0], w_inn[1], w_inn[2])) @ Cbn) * dt

                roll, pitch,yaw = DCM2eul_bn(Cbn)  # attitude update

                kalman_yaw.value = yaw # 우리가 쓸 yaw 값 !!

                # -------------velocity update

                V_ned = np.array([v_n, v_e, v_d])

                m_2 = Cbn @ np.array([[current_accel_x.value - dX[9][0]],
                                      [current_accel_y.value - dX[10][0]],
                                      [current_accel_z.value - dX[11][0]]])

                m_5 = np.array([w_ien[0] * 2, w_ien[1] * 2, w_ien[2] * 2]) + np.array([w_enn[0], w_enn[1], w_enn[2]])

                m_7 = m_2 - np.array(np.cross(m_5, V_ned)).reshape((-1, 1))
                m_8 = (m_7 + np.array([[0], [0], [g]])) * dt
                V = V_ned.reshape((-1, 1)) + m_8

                # velocity update
                # -------------velocity update

                # -------------Position update

                lat = lat + (180 / math.pi) * (0.5 * (V[0][0] + v_n) / (Rm + h)) * dt
                lon = lon + (180 / math.pi) * (0.5 * (V[1][0] + v_e) / ((Rt + h) * math.cos(lat * degree))) * dt
                h = h - (180 / math.pi) * (0.5 * (V[2][0] + v_d)) * dt

                # -----------------
                X = np.array([lat, lon, h, V[0][0], V[1][0], V[2][0], roll, pitch, yaw])  # next state

                # Kalman filter

                F = np.array(
                    Kalman_Filter(lat, h, Rm, Rt, Rmm, Rtt, rho_n, rho_e, rho_d, v_n, v_e, v_d, f_n, f_e, f_d, w_ien, Cbn))
                A = dt * F
                A = linalg.expm(A)  # discretization F matrix

                # -------------Prediction
                dX = A @ dX  # error state prediction
                P = A @ P @ np.transpose(A) + Q  # P prediction

                X_copy = X.tolist()
                X_copy = copy.deepcopy(X_copy)

                if GPS_CNT.value > G_CNT: # GPS 정보가 들어옴
                    G_CNT = GPS_CNT.value

                    # 255 인 경우는 적용안됨
                    N, E, D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value, start_lat,
                                                             start_lon, start_alt)

                    # init_N, init_E, init_D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value,
                    #                                          start_lat, start_lon, start_alt)
                    GPS_yaw = math.atan2(E - prev_E, N - prev_N) * radian
                    # print("GPS : ", GPS_yaw)
                    # print("Kalman : ",yaw)
                    error = GPS_yaw - yaw

                    # print('...')

                    GPS_v_n,GPS_v_e,GPS_v_d = (N - prev_N) / dt,(E - prev_E) / dt,(D - prev_D) / dt

                    K = P @ np.transpose(H) @ np.linalg.inv(H @ P @ np.transpose(H) + R)  # Kalman gain

                    z = np.array([
                        [X_copy[0] - current_lat.value],
                        [X_copy[1] - current_lon.value],
                        [X_copy[2] - current_alt.value],
                        [X_copy[3] - GPS_v_n],
                        [X_copy[4] - GPS_v_e],
                        [X_copy[5] - GPS_v_d]
                    ])

                    dX = dX + (K @ (z - (H @ dX)))

                    P = P - K @ H @ P

                    X[0] = X_copy[0] - dX[0]
                    X[1] = X_copy[1] - dX[1]
                    X[2] = X_copy[2] - dX[2]
                    X[3] = X_copy[3] - dX[3]
                    X[4] = X_copy[4] - dX[4]
                    X[5] = X_copy[5] - dX[5]

                    dX = copy.deepcopy(dX0)
                    prev_N, prev_E, prev_D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value, start_lat,
                                                         start_lon, start_alt)

                elif G_CNT == 255 and GPS_CNT.value == 0: # 255일때 대응 가능
                    G_CNT = GPS_CNT.value

                    N, E, D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value, start_lat,
                                              start_lon, start_alt)

                    GPS_v_n,GPS_v_e,GPS_v_d = (N - prev_N) / dt,(E - prev_E) / dt,(D - prev_D) / dt

                    K = P @ np.transpose(H) @ np.linalg.inv(H @ P @ np.transpose(H) + R)  # Kalman gain

                    z = np.array([
                        [X_copy[0] - current_lat.value],
                        [X_copy[1] - current_lon.value],
                        [X_copy[2] - current_alt.value],
                        [X_copy[3] - GPS_v_n],
                        [X_copy[4] - GPS_v_e],
                        [X_copy[5] - GPS_v_d]
                    ]) # error measurment update

                    dX = dX + (K @ (z - (H @ dX)))

                    P = P - K @ H @ P

                    X[0] = X_copy[0] - dX[0]
                    X[1] = X_copy[1] - dX[1]
                    X[2] = X_copy[2] - dX[2]
                    X[3] = X_copy[3] - dX[3]
                    X[4] = X_copy[4] - dX[4]
                    X[5] = X_copy[5] - dX[5]

                    dX = copy.deepcopy(dX0)
                    prev_N, prev_E, prev_D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value, start_lat,
                                                             start_lon, start_alt)

                else:
                    pass

                GPS_N, GPS_E, GPS_D = pm.geodetic2ned(current_lat.value, current_lon.value, current_alt.value,
                                                         start_lat,
                                                         start_lon, start_alt)

                GPS_comp_plot = np.append(GPS_comp_plot, np.array([[GPS_E, GPS_N]]), axis=0)

                Kalman_N, Kalman_E, Kalman_D = pm.geodetic2ned(X[0], X[1], X[2], start_lat, start_lon, start_alt)

                Kalman_comp_plot = np.append(Kalman_comp_plot, np.array([[Kalman_E, Kalman_N]]), axis=0)


if __name__ == '__main__':
    current_lat = Value('d', 0.0)
    current_lon = Value('d', 0.0)
    current_alt = Value('d', 0.0)
    current_accel_x = Value('d', 0.0)
    current_accel_y = Value('d', 0.0)
    current_accel_z = Value('d', 0.0)
    current_vel_x = Value('d', 0.0)
    current_vel_y = Value('d', 0.0)
    current_vel_z = Value('d', 0.0)
    current_quat_x = Value('d', 0.0)
    current_quat_y = Value('d', 0.0)
    current_quat_z = Value('d', 0.0)
    current_quat_w = Value('d', 0.0)
    current_yaw = Value('d', 0.0)
    

    #obj = [dist,x_cent, y_cent, x_min,x_max, y_min, y_max]
    obj1_dist = Value('d', 0.0)
    obj2_dist = Value('d', 0.0)
    obj3_dist = Value('d', 0.0)
    obj4_dist = Value('d', 0.0)
    
    obj1_x_cent = Value('d', 0.0)
    obj2_x_cent = Value('d', 0.0)
    obj3_x_cent = Value('d', 0.0)
    obj4_x_cent = Value('d', 0.0)

    obj1_y_cent = Value('d', 0.0)
    obj2_y_cent = Value('d', 0.0)
    obj3_y_cent = Value('d', 0.0)
    obj4_y_cent = Value('d', 0.0)

    obj1_x_min = Value('d', 0.0)
    obj2_x_min = Value('d', 0.0)
    obj3_x_min = Value('d', 0.0)
    obj4_x_min = Value('d', 0.0)

    obj1_x_max = Value('d', 0.0)
    obj2_x_max = Value('d', 0.0)
    obj3_x_max = Value('d', 0.0)
    obj4_x_max = Value('d', 0.0)

    obj1_y_min = Value('d', 0.0)
    obj2_y_min = Value('d', 0.0)
    obj3_y_min = Value('d', 0.0)
    obj4_y_min = Value('d', 0.0)

    obj1_y_max = Value('d', 0.0)
    obj2_y_max = Value('d', 0.0)
    obj3_y_max = Value('d', 0.0)
    obj4_y_max = Value('d', 0.0)

    IMU_CTC    = Value('d', 0.0)
    IMU_CNT    = Value('d', 0.0)
    GPS_CTC    = Value('d', 0.0)
    GPS_CNT    = Value('d', 0.0)
    LIDAR_CTC  = Value('d', 0.0)
    LIDAR_CNT  = Value('d', 0.0)
    
    LIDAR_obj_1 = Value('d', 0.0)
    LIDAR_obj_2 = Value('d', 0.0)
    LIDAR_obj_3 = Value('d', 0.0)
    LIDAR_obj_4 = Value('d', 0.0)

    current_roll = Value('d', 0.0)
    current_pitch = Value('d', 0.0)

    kalman_yaw = Value('d', 0.0)




    

    th1 = Process(target=GPSINS, args=(current_lat, current_lon, current_alt, current_accel_x,
    current_accel_y, current_accel_z,current_vel_x, current_vel_y,current_vel_z,
    current_quat_x, current_quat_y, current_quat_z,
    current_quat_w,current_yaw,
    obj1_dist,obj2_dist,obj3_dist,obj4_dist,
    obj1_x_cent,obj2_x_cent,obj3_x_cent,obj4_x_cent,
    obj1_y_cent,obj2_y_cent,obj3_y_cent ,obj4_y_cent,
    obj1_x_min,obj2_x_min,obj3_x_min,obj4_x_min,
    obj1_x_max,obj2_x_max,obj3_x_max,obj4_x_max,
    obj1_y_min,obj2_y_min,obj3_y_min,obj4_y_min,
    obj1_y_max,obj2_y_max,obj3_y_max,obj4_y_max,
    IMU_CTC, IMU_CNT, GPS_CTC,GPS_CNT,LIDAR_CTC,LIDAR_CNT,
    LIDAR_obj_1,LIDAR_obj_2,LIDAR_obj_3,LIDAR_obj_4, current_roll,current_pitch
    ))


    th2 = Process(target=tcpip, args=(current_lat, current_lon, current_alt, current_accel_x,
    current_accel_y, current_accel_z,current_vel_x, current_vel_y,current_vel_z,
    current_quat_x, current_quat_y, current_quat_z,
    current_quat_w,current_yaw,obj1_dist,obj2_dist,obj3_dist,obj4_dist,
    obj1_x_cent,obj2_x_cent,obj3_x_cent,obj4_x_cent,
    obj1_y_cent,obj2_y_cent,obj3_y_cent ,obj4_y_cent,
    obj1_x_min,obj2_x_min,obj3_x_min,obj4_x_min,
    obj1_x_max,obj2_x_max,obj3_x_max,obj4_x_max,
    obj1_y_min,obj2_y_min,obj3_y_min,obj4_y_min,
    obj1_y_max,obj2_y_max,obj3_y_max,obj4_y_max,
    IMU_CTC, IMU_CNT, GPS_CTC,GPS_CNT,LIDAR_CTC,LIDAR_CNT,
    LIDAR_obj_1,LIDAR_obj_2,LIDAR_obj_3,LIDAR_obj_4,kalman_yaw
    ))


    th3 = Process(target=vn100_Kalman_filter, args = (current_lat, current_lon, current_alt, current_accel_x,
    current_accel_y, current_accel_z,current_vel_x, current_vel_y,current_vel_z,current_yaw,current_roll,current_pitch,GPS_CNT,kalman_yaw,GPS_CTC))

    th1.start()
    th2.start()
    th3.start()



    
    
