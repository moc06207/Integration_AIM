#include "ros/ros.h"
#include <iostream>
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/FluidPressure.h"
#include "nav_msgs/Odometry.h"
#include "vn/sensors.h"
#include "sensor_msgs/Temperature.h"
#include "sensor_msgs/MagneticField.h"
#include "vn/compositedata.h"
#include "vn/util.h"
#include "rtcm_msgs/Message.h"
#include <cmath>
#include <string>
#include <sstream>
#include <fstream>

#include "sensor_msgs/NavSatFix.h"
#include "geometry_msgs/TwistWithCovarianceStamped.h"
#include "ublox_msgs/NavCLOCK.h"
#include "ublox_msgs/NavPOSECEF.h"
#include "ublox_msgs/NavPVT7.h"

#include "ublox_msgs/CfgGNSS_Block.h"
#include "sensor_msgs/NavSatStatus.h"
#include "ublox_msgs/CfgGNSS.h"
#include "ublox_msgs/CfgGNSS_Block.h"

#include "ublox_msgs/NavRELPOSNED.h"
#include "ublox_msgs/NavSAT.h"
#include "ublox_msgs/NavSTATUS.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

#include <rtcm_msgs/Message.h>


#include <vectornav/Ins.h>



using namespace std;

void msgcallback(const sensor_msgs::Imu::ConstPtr& msg)
{
	//vectornav/IMU
	ROS_INFO("x1 msg=%6f", msg->orientation.x);
	ROS_INFO("y1 msg=%6f", msg->orientation.y);
	ROS_INFO("z1 msg=%6f", msg->orientation.z);
	ROS_INFO("w1 msg=%6f", msg->orientation.w);

	ROS_INFO("av_x1 msg=%6f", msg->angular_velocity.x);
	ROS_INFO("av_y1 msg=%6f", msg->angular_velocity.y);
	ROS_INFO("av_z1 msg=%6f", msg->angular_velocity.z);

	ROS_INFO("la_x1 msg=%6f", msg->linear_acceleration.x);
	ROS_INFO("la_y1 msg=%6f", msg->linear_acceleration.y);
	ROS_INFO("la_z1 msg=%6f", msg->linear_acceleration.z);
}

void msgcallback1(const vectornav::Ins::ConstPtr& msg)
{
	//vectornav/INS
	ROS_INFO("Ins_time1 msg=%7f", msg->time);
	ROS_INFO("Ins_week1 msg=%7d", msg->week);
	ROS_INFO("UTC_time1 msg=%ld", msg->utcTime);
	ROS_INFO("Ins_Status1 msg=%7d", msg->insStatus);

	ROS_INFO("yaw1 msg=%7f", msg->yaw);
	ROS_INFO("pitch1 msg=%7f", msg->pitch);
	ROS_INFO("roll1 msg=%7f", msg->roll);

	ROS_INFO("lat1 msg=%7f", msg->latitude);
	ROS_INFO("lon1 msg=%7f", msg->longitude);
	ROS_INFO("alt1 msg=%7f", msg->altitude);

	ROS_INFO("nedX1 msg=%7f", msg->nedVelX);
	ROS_INFO("nedY1 msg=%7f", msg->nedVelY);
	ROS_INFO("nedZ1 msg=%7f", msg->nedVelZ);

	ROS_INFO("atU0 msg=%7f", msg->attUncertainty[0]);
	ROS_INFO("atU1 msg=%7f", msg->attUncertainty[1]);
	ROS_INFO("atU2 msg=%7f", msg->attUncertainty[2]);

	ROS_INFO("posU1 msg=%7f", msg->posUncertainty);
	ROS_INFO("velU1 msg=%7f", msg->velUncertainty);
}

void msgcallback2(const sensor_msgs::NavSatFix::ConstPtr& msg)
{
	//vectornav/GPS
	ROS_INFO("sta1 msg=%d", msg->status.status);
	ROS_INFO("poscov0 msg=%7f", msg->position_covariance[0]);
	ROS_INFO("poscov4 msg=%7f", msg->position_covariance[4]);
	ROS_INFO("poscov8 msg=%7f", msg->position_covariance[8]);
	ROS_INFO("poscovtype1 msg=%d", msg->position_covariance_type);
}

void msgcallback3(const sensor_msgs::MagneticField::ConstPtr &msg)
{
	//vectornav/Mag
	ROS_INFO("magx1 msg=%7f", msg->magnetic_field.x);
	ROS_INFO("magy1 msg=%7f", msg->magnetic_field.y);
	ROS_INFO("magz1 msg=%7f", msg->magnetic_field.z);
}

void msgcallback4(const nav_msgs::Odometry::ConstPtr& msg)
{
	//vectornav/Odom
	ROS_INFO("posx1 msg=%7f", msg->pose.pose.position.x);
	ROS_INFO("posy1 msg=%7f", msg->pose.pose.position.y);
	ROS_INFO("posz1 msg=%7f", msg->pose.pose.position.z);

	ROS_INFO("orix1 msg=%7f", msg->pose.pose.orientation.x);
	ROS_INFO("oriy1 msg=%7f", msg->pose.pose.orientation.y);
	ROS_INFO("oriz1 msg=%7f", msg->pose.pose.orientation.z);
	ROS_INFO("oriw1 msg=%7f", msg->pose.pose.orientation.w);

	ROS_INFO("cov21 msg=%7f", msg->pose.covariance[21]);
	ROS_INFO("cov28 msg=%7f", msg->pose.covariance[28]);
	ROS_INFO("cov35 msg=%7f", msg->pose.covariance[35]);

	ROS_INFO("linx1 msg=%7f", msg->twist.twist.linear.x);
	ROS_INFO("liny1 msg=%7f", msg->twist.twist.linear.y);
	ROS_INFO("linz1 msg=%7f", msg->twist.twist.linear.z);

	ROS_INFO("angx1 msg=%7f", msg->twist.twist.angular.x);
	ROS_INFO("angy1 msg=%7f", msg->twist.twist.angular.y);
	ROS_INFO("angz1 msg=%7f", msg->twist.twist.angular.z);

	ROS_INFO("cov0 msg=%7f", msg->twist.covariance[0]);
	ROS_INFO("cov7 msg=%7f", msg->twist.covariance[7]);
	ROS_INFO("cov15 msg=%7f", msg->twist.covariance[15]);
}

void msgcallback5(const sensor_msgs::FluidPressure::ConstPtr& msg)
{
	//vectornav/Pres
	ROS_INFO("Pres=%7f", msg->fluid_pressure);
}

void msgcallback6(const sensor_msgs::Temperature::ConstPtr& msg)
{
	//vectornav/Temp
	ROS_INFO("Temp=%7f", msg->temperature);
}

void msgcallbackfix(const sensor_msgs::NavSatFix::ConstPtr& msg)
{
	//raw_data/fix
	ROS_INFO("lat msg=%2.7f", msg->latitude);
	ROS_INFO("lon msg=%3.7f", msg->longitude);
	ROS_INFO("alt msg=%2.3f", msg->altitude);
	ROS_INFO("pos_cov0 msg=%1.25f", msg->position_covariance[0]);
	ROS_INFO("pos_cov4 msg=%7f", msg->position_covariance[4]);
	ROS_INFO("pos_cov8 msg=%1.9f", msg->position_covariance[8]);
	ROS_INFO("pos_cov_type msg=%2d", msg->position_covariance_type);
}

void msgcallbackfixvelocity(const geometry_msgs::TwistWithCovarianceStamped::ConstPtr& msg)
{
	// //raw_data/fix_velocity
	ROS_INFO("twix1 msg=%1.3f", msg->twist.twist.linear.x);
	ROS_INFO("twiy1 msg=%1.3f", msg->twist.twist.linear.y);
	ROS_INFO("twiz1 msg=%1.3f", msg->twist.twist.linear.z);
	ROS_INFO("twi_cov00 msg=%1.6f", msg->twist.covariance[cols*0+0]);
	ROS_INFO("twi_cov11 msg=%1.6f", msg->twist.covariance[cols*1+1]);
	ROS_INFO("twi_cov22 msg=%1.6f", msg->twist.covariance[cols*2+2]);
	ROS_INFO("twi_cov33 msg=%1.6f", msg->twist.covariance[cols*3+3]);
}

void msgcallbacknavclock(const ublox_msgs::NavCLOCK::ConstPtr& msg)
{
	//raw_data/navclock
	ROS_INFO("iTOW1 msg=%10d", msg->iTOW);
	ROS_INFO("clkB1 msg=%7d", msg->clkB);
	ROS_INFO("clkD1 msg=%4d", msg->clkD);
	ROS_INFO("tAcc msg=%2d", msg->tAcc);
	ROS_INFO("fAcc msg=%4d", msg->fAcc);
}

void msgcallbacknavposecef(const ublox_msgs::NavPOSECEF::ConstPtr& msg)
{
	//raw_data/navposecef
	ROS_INFO("iTOW1 msg=%10d", msg->iTOW);
	ROS_INFO("ecefX1 msg=%10d", msg->ecefX);
	ROS_INFO("ecefY1 msg=%10d", msg->ecefY);
	ROS_INFO("ecefZ1 msg=%10d", msg->ecefZ);
	ROS_INFO("pAcc msg=%2d", msg->pAcc);
}

void msgcallbacknavpvt(const ublox_msgs::NavPVT7::ConstPtr& msg)
{
	//raw_data/navpvt
	ROS_INFO("iTOW msg=%x", msg->iTOW);
	ROS_INFO("year msg=%5d", msg->year);
	ROS_INFO("month msg=%2d", msg->month);
	ROS_INFO("day msg=%2d", msg->day);
	ROS_INFO("hour msg=%2d", msg->hour);
	ROS_INFO("min msg=%2d", msg->min);
	ROS_INFO("sec msg=%2d", msg->sec);
	ROS_INFO("valid msg=%3d", msg->valid);
	ROS_INFO("nano msg=%x", msg->nano);
	//ROS_INFO("gpsFix msg=%2d", msg->gpsFix);
	ROS_INFO("flags msg=%4d", msg->flags);
	//ROS_INFO("reserved0 msg=%4d", msg->reserved0);
	ROS_INFO("lon msg=%d", msg->lon);
	ROS_INFO("lat msg=%d", msg->lat);
	ROS_INFO("height msg=%6d", msg->height);
	//ROS_INFO("LMSL msg=%6d", msg->LMSL);
	ROS_INFO("gSpeed msg=%2d", msg->gSpeed);
	ROS_INFO("headMot msg=%d", msg->heading);
	//ROS_INFO("hesdVeh msg=%lu", msg->hesdVeh);
	ROS_INFO("hAcc msg=%3d", msg->hAcc);
	ROS_INFO("vAcc msg=%3d", msg->vAcc);
	ROS_INFO("sAcc msg=%3d", msg->sAcc);
	ROS_INFO("headAcc msg=%9d", msg->headAcc);
	//ROS_INFO("reserved1 msg=%c", msg->reserved1);
}

void msgcallbacknavrelposned(const ublox_msgs::NavRELPOSNED::ConstPtr& msg)
{
	//raw_data/navrelposned
	ROS_INFO("version msg=%2d", msg->version);
	ROS_INFO("reserved0 msg=%2d", msg->reserved0);
	ROS_INFO("refStationId msg=%2d", msg->refStationId);
	ROS_INFO("iTOW msg=%10d", msg->iTow);
	ROS_INFO("relPosN msg=%6d", msg->relPosN);
	ROS_INFO("relPosE msg=%6d", msg->relPosE);
	ROS_INFO("relPosD msg=%5d", msg->relPosD);
	ROS_INFO("relPosLength msg=%7d", msg->relPosLength);
	ROS_INFO("relPosHeading msg=%9d", msg->relPosHeading);
	ROS_INFO("reserved1 msg=%2d", msg->reserved1);
	ROS_INFO("relPosHPN msg=%3d", msg->relPosHPN);
	ROS_INFO("relPosHPE msg=%3d", msg->relPosHPE);
	ROS_INFO("relPosHPD msg=%2d", msg->relPosHPD);
	ROS_INFO("relPosHPLength msg=%2d", msg->relPosHPLength);
	ROS_INFO("accN msg=%4d", msg->accN);
	ROS_INFO("accE msg=%4d", msg->accE);
	ROS_INFO("accD msg=%4d", msg->accD);
	ROS_INFO("accLength msg=%4d", msg->accLength);
	ROS_INFO("accHeading msg=%3d", msg->accHeading);
	ROS_INFO("reserved2 msg=%2d", msg->reserved2);
	ROS_INFO("flags msg=%4d", msg->flags);
}

void msgcallbacknavsat(const ublox_msgs::NavSAT::ConstPtr& msg)
{
	raw_data/navsat
	ROS_INFO("gnssId msg=%2d", msg->gnssId);
	ROS_INFO("svId msg=%3d", msg->sv);
	ROS_INFO("cno msg=%3d", msg->cno);
	ROS_INFO("elev msg=%3d", msg->elev);
	ROS_INFO("azim msg=%4d", msg->azim);
	ROS_INFO("prRes msg=%4d", msg->prRes);
	ROS_INFO("flags msg=%5d", msg->flags);
}

void msgcallbacknavstatus(const ublox_msgs::NavSTATUS::ConstPtr& msg)
{
	//raw_data/navstatus
	ROS_INFO("iTOW msg=%10d", msg->iTOW);
	//ROS_INFO("gpsFix msg=%2d", msg->gpsFix);
	ROS_INFO("flags msg=%4d", msg->flags);
	ROS_INFO("fixStat msg=%2d", msg->fixStat);
	ROS_INFO("flags2 msg=%4d", msg->flags2);
	ROS_INFO("ttff msg=%7d", msg->ttff);
	ROS_INFO("msss msg=%7d", msg->msss);
}

int main(int argc, char** argv)
{
	
	ros::init(argc, argv, "imu_subscriber");
	ros::NodeHandle nh;
	ros::NodeHandle pn("~");

	ros::Subscriber ros_tutorial_IMU = nh.subscribe("vectornav/IMU", 1000, msgcallback);
	ros::Subscriber ros_tutorial_INS = nh.subscribe("vectornav/INS", 1000, msgcallback1);
	ros::Subscriber ros_tutorial_GPS = nh.subscribe("vectornav/GPS", 1000, msgcallback2);
	ros::Subscriber ros_tutorial_Mag = nh.subscribe("vectornav/Mag", 1000, msgcallback3);
	ros::Subscriber ros_tutorial_Odom = nh.subscribe("vectornav/Odom", 1000, msgcallback4);
	ros::Subscriber ros_tutorial_Pres = nh.subscribe("vectornav/Pres", 1000, msgcallback5);
	ros::Subscriber ros_tutorial_Temp = nh.subscribe("vectornav/Temp", 1000, msgcallback6);
	
	ros::Subscriber ros_tutorial_fix = nh.subscribe("raw_data/fix", 1000, msgcallbackfix);
	ros::Subscriber ros_tutorial_fix_velocity = nh.subscribe("raw_data/fix_velocity", 10000, msgcallbackfixvelocity); //오류
	ros::Subscriber ros_tutorial_navclock = nh.subscribe("raw_data/navclock", 1000, msgcallbacknavclock);
	ros::Subscriber ros_tutorial_navposecef = nh.subscribe("raw_data/navposecef", 1000, msgcallbacknavposecef);
	ros::Subscriber ros_tutorial_navpvt = nh.subscribe("raw_data/navpvt", 1000, msgcallbacknavpvt); //오류
	ros::Subscriber ros_tutorial_navrelposned = nh.subscribe("raw_data/navrelposned", 1000, msgcallbacknavrelposned);
	ros::Subscriber ros_tutorial_navsat = nh.subscribe("raw_data/navsat", 1000, msgcallbacknavsat); //오류
	ros::Subscriber ros_tutorial_navstatus = nh.subscribe("raw_data/navstatus", 1000, msgcallbacknavstatus);



	ros::spin();
	return 0;
}